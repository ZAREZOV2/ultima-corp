// Инициализация темы
function initTheme() {
    const isDarkMode = localStorage.theme === 'dark' ||
        (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches);

    if (isDarkMode) {
        document.documentElement.classList.add('dark');
    } else {
        document.documentElement.classList.remove('dark');
    }
}

// Переключение темы
function toggleTheme() {
    const isDark = document.documentElement.classList.toggle('dark');
    localStorage.theme = isDark ? 'dark' : 'light';
}

// Мобильное меню
function toggleMobileMenu() {
    const menu = document.getElementById('mobileMenu');
    menu.classList.toggle('hidden');
    menu.classList.toggle('active');
}

// Прокрутка вверх с плавной анимацией
function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

// Снегопад
const icons = ['👻', '🎃']; // '❄', '☠'
let snowflakesCount = 0; // <- должна быть глобальной!
const maxSnowflakes = 15;

function createSnowflake() {
    if (snowflakesCount >= maxSnowflakes) return;
    snowflakesCount++;
    const snowflake = document.createElement('div');
    snowflake.innerHTML = icons[Math.floor(Math.random() * icons.length)];
    snowflake.classList.add('snowflake');
    snowflake.style.position = 'fixed';
    snowflake.style.left = Math.random() * window.innerWidth + 'px';
    snowflake.style.top = '-20px';
    snowflake.style.fontSize = Math.random() * 20 + 10 + 'px';
    snowflake.style.opacity = 0;
    snowflake.style.willChange = 'transform, opacity, left, top';
    snowflake.style.transition = 'opacity 0.6s, transform 1s';
    snowflake.style.zIndex = '49';
    snowflake.style.color = document.documentElement.classList.contains('dark') ? '#a0aec0' : '#4a5568';
    document.getElementById('snowfall').appendChild(snowflake);

    setTimeout(() => {
        snowflake.style.opacity = Math.random() * 0.6 + 0.4;
    }, 20);

    let angle = Math.random() * 360;
    const drift = Math.random() * 2 - 1;
    const speed = Math.random() * 3 + 1;
    const initialLeft = parseFloat(snowflake.style.left);

    function fall() {
        const currentTop = parseFloat(snowflake.style.top);
        if (currentTop > window.innerHeight) {
            snowflake.style.opacity = 0;
            setTimeout(() => {
                snowflake.remove();
                snowflakesCount--;
            }, 500);
            return;
        }
        angle += drift * 2;
        snowflake.style.top = currentTop + speed + 'px';
        snowflake.style.left = initialLeft + Math.sin(currentTop / 30) * 20 + drift + 'px';
        snowflake.style.transform = `rotate(${angle}deg)`;
        requestAnimationFrame(fall);
    }
    fall();
}

// Плавное появление элементов при прокрутке
function initScrollAnimations() {
    const fadeElements = document.querySelectorAll('.fade-in');

    const checkVisibility = () => {
        fadeElements.forEach(element => {
            const rect = element.getBoundingClientRect();
            if (rect.top < window.innerHeight * 0.8) {
                element.classList.add('visible');
            }
        });
    };

    window.addEventListener('scroll', checkVisibility);
    checkVisibility(); // Проверяем при загрузке страницы
}

// Инициализация
document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    document.getElementById('themeToggle').addEventListener('click', toggleTheme);
    setInterval(createSnowflake, 200);
    initScrollAnimations();
});

// Loaders
function hideLoader() {
    const loader = document.getElementById('loader');
    loader.style.opacity = '0';
    setTimeout(() => {
        loader.style.display = 'none';
    }, 300); // Плавное исчезновение
}

window.addEventListener('load', hideLoader);

// Шапка сайта
document.addEventListener('DOMContentLoaded', () => {
    const header = document.querySelector('header');

    // Добавляем класс 'visible' сразу при загрузке страницы
    header.classList.add('visible');

    const checkScroll = () => {
        if (window.scrollY > 50) {
            header.classList.add('scrolled'); // Добавляем класс при прокрутке
        } else {
            header.classList.remove('scrolled'); // Убираем класс при возврате вверх
        }
    };

    window.addEventListener('scroll', checkScroll);
    checkScroll(); // Проверяем при загрузке страницы
});

// Эффект при клике
document.addEventListener('DOMContentLoaded', () => {
    const links = document.querySelectorAll('header a');

    links.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault(); // Отключаем стандартное поведение ссылки

            // Эффект пульсации
            gsap.to(link, {
                scale: 0.9,
                duration: 0.1,
                yoyo: true,
                repeat: 1,
                ease: 'power1.inOut',
                onComplete: () => {
                    window.location.href = link.href; // Переход по ссылке после анимации
                }
            });
        });
    });
});

// Эффект при клике (mobile)
function toggleMobileMenu() {
    const menu = document.getElementById('mobileMenu');

    if (menu.classList.contains('hidden')) {
        menu.classList.remove('hidden');
        gsap.fromTo(menu,
            { opacity: 0, y: -20 },
            { opacity: 1, y: 0, duration: 0.3, ease: 'power1.out' }
        );
    } else {
        gsap.to(menu, {
            opacity: 0,
            y: -20,
            duration: 0.3,
            ease: 'power1.in',
            onComplete: () => {
                menu.classList.add('hidden');
            }
        });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const newsCards = document.querySelectorAll('.news-card.fade-in');

    const checkVisibility = () => {
        newsCards.forEach(card => {
            const rect = card.getBoundingClientRect();
            if (rect.top < window.innerHeight * 0.8) {
                card.classList.add('visible');
            }
        });
    };

    window.addEventListener('scroll', checkVisibility);
    checkVisibility(); // Проверяем при загрузке страницы
});