const express = require('express');
const path = require('path');

const app = express();
const PORT = 5000;

// Указываем, что статические файлы находятся в папке public
app.use(express.static(path.join(__dirname, 'public')));

const VIEWS_PATH = path.join(__dirname, 'views');

// Роут для главной страницы
app.get('/', (req, res) => {
    res.sendFile(path.join(VIEWS_PATH, 'index.html'));
});

// Роут для страницы about
app.get('/about', (req, res) => {
    res.sendFile(path.join(VIEWS_PATH, 'about.html'));
});

// Роут для страницы contact
app.get('/contact', (req, res) => {
    res.sendFile(path.join(VIEWS_PATH, 'contact.html'));
});

// Для сжатия статических файлов (CSS, JS, изображений)
const compression = require('compression');
app.use(compression());

// Кэширование статических страниц
app.use(express.static(path.join(__dirname, 'public'), {
    maxAge: '1y', // Кэшировать на год
    etag: false,  // Отключить ETag для упрощения
}));

// Заголовки безопасности
app.use((req, res, next) => {
    res.setHeader('Content-Security-Policy', "default-src 'self'");
    res.setHeader('X-Content-Type-Options', 'nosniff');
    next();
});

// Запуск сервера
app.listen(PORT, () => {
    console.log(`Сервер запущен на http://localhost:${PORT}`);
});